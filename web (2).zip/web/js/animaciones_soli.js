const eventos = [
  {
    nombre: "Noche Indie",
    fecha: "2027-06-10",
    hora: "21:30",
    aforo: 400,
    lugar: "Fuengirola",
    descripcion: "Evento para grupos emergentes."
  },
  {
    nombre: "Electronic Summer",
    fecha: "2027-07-22",
    hora: "23:00",
    aforo: 900,
    lugar: "Marbella",
    descripcion: "Festival de música electrónica."
  }
];

function renderEventos() {

  const q = document.getElementById("q").value.toLowerCase();
  const fecha = document.getElementById("fFecha").value;
  const hora = document.getElementById("fHora").value;
  const aforo = document.getElementById("fAforo").value;

  const resultados = eventos.filter(e => {

    const coincideNombre =
      e.nombre.toLowerCase().includes(q);

    const coincideFecha =
      !fecha || e.fecha === fecha;

    const coincideHora =
      !hora || e.hora === hora;

    const coincideAforo =
      !aforo ||
      (aforo == "100" && e.aforo <= 100) ||
      (aforo == "500" && e.aforo > 100 && e.aforo <= 500) ||
      (aforo == "1000" && e.aforo > 500 && e.aforo <= 1000) ||
      (aforo == "2000" && e.aforo > 1000);

    return (
      coincideNombre &&
      coincideFecha &&
      coincideHora &&
      coincideAforo
    );
  });

  document.getElementById("results").innerHTML =
    resultados.length > 0
      ? resultados.map(e => `
        <div class="card">

          <span class="tag">🎫 Evento</span>

          <h3>${e.nombre}</h3>

          <p>📍 <strong>Lugar:</strong> ${e.lugar}</p>
          <p>📅 <strong>Fecha:</strong> ${e.fecha}</p>
          <p>🕒 <strong>Hora:</strong> ${e.hora}</p>
          <p>👥 <strong>Aforo:</strong> ${e.aforo} personas</p>

          <p>${e.descripcion}</p>

          <button
            class="btn btn-primary"
            onclick="enviarMensaje('${e.nombre}')">
            Enviar mensaje
          </button>

        </div>
      `).join("")
      : `
        <p style="text-align:center;">
          No se encontraron eventos.
        </p>
      `;
}

function enviarMensaje(evento) {

  const mensaje =
`Buenas tardes.

Estoy interesado en participar en el evento "${evento}".

¿Podrían facilitarme más información?

Muchas gracias.`;

  alert(mensaje);
}

renderEventos();
// MENU HAMBURGUESA

const burger = document.getElementById("burger");
const navLinks = document.getElementById("navLinks");

if (burger && navLinks) {
  burger.addEventListener("click", () => {
    navLinks.classList.toggle("open");
  });
}

// MODAL LOGIN

function openModal(tipo) {

  const modal = document.getElementById("modal");
  const modalContent = document.getElementById("modalContent");

  if (!modal || !modalContent) return;

  if (tipo === "login") {

    modalContent.innerHTML = `
      <h3>Iniciar sesión</h3>

      <form onsubmit="fakeSubmit(event)">

        <div class="field">
          <label>Correo electrónico</label>
          <input type="email" required>
        </div>

        <div class="field">
          <label>Contraseña</label>
          <input type="password" required>
        </div>

        <button class="btn btn-primary w100">
          Entrar
        </button>

          <div id="okMsg" class="msg"></div>

      </form>
    `;
  }

  modal.classList.add("open");
}

function closeModal() {
  document.getElementById("modal").classList.remove("open");
}

function fakeSubmit(event) {

  event.preventDefault();

  const okMsg = document.getElementById("okMsg");

  okMsg.textContent = "Sesión iniciada correctamente";
  okMsg.style.display = "block";

  setTimeout(() => {
    closeModal();
  }, 2000);
}

// CERRAR MODAL AL HACER CLICK FUERA

const modal = document.getElementById("modal");

if (modal) {
  modal.addEventListener("click", (e) => {
    if (e.target.id === "modal") {
      closeModal();
    }
  });
}